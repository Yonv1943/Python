from os import path
import os
import sys
import time
import shutil

import cv2
import numpy as np

os.environ["TF_CPP_MIN_LOG_LEVEL"] = '2'
import tensorflow as tf
from main import GlobalVariable

"""
Author: Yonv1943
2018-08-28 17:46:17 stable
|full connect 2 layers
    |Train_set |Accuracy: 90.4273% |Error: 9.57e-02
    |Test_set  |Accuracy: 91.3300% |Error: 8.67e-02
    | NVIDIA GTX 710 training for 8s

|pad conv2d
    |Train_set |Accuracy: 99.9636% |Error: 3.64e-04
    |Test_set  |Accuracy: 99.0500% |Error: 9.50e-03
    |NVIDIA Tesla K80 training for 1122s (Google Colab)
|DenseNet
	| Train_set |Accuracy: 98.6545% |Error: 1.35e-02
	| Test_set  |Accuracy: 98.4700% |Error: 1.53e-02
	| NVIDIA Tesla V100 training for 29s, 200kb
2018-08-29 16:16:30 complete   
2018-08-29 16:41:10 simplify 
2018-09-13 09:38:11 DenseNet
"""


class Tools(object):
    def ten_check(self, ten):
        return tf.Print(ten, [str(ten.shape)], message='|| ')

    def img_check(self, img):
        print("| min,max %6.2f %6.2f |%s", img.shape, np.min(img), np.max(img))

    def ary_check(self, ary):
        print("| min,max %6.2f %6.2f |ave,std %6.2f %6.2f |%s" %
              (np.min(ary), np.max(ary), np.average(ary), float(np.std(ary)), ary.shape,))

    def draw_plot(self, txt_path):
        print("||" + self.draw_plot.__name__)
        if not path.exists(txt_path):  # check
            print("|NotExist:", txt_path)
            return None

        ary = np.loadtxt(txt_path)
        if ary.shape[0] < 2:
            print("|Empty:", txt_path)
        else:
            ary = ary[int(len(ary) * 0.05):]
            x_pts = [i for i in range(ary.shape[0])]
            y_pts = ary[:, 0]
            e_pts = ary[:, 1]

            if 'plt' not in globals():
                import matplotlib.pyplot as plt_global
                global plt
                plt = plt_global
            plt.plot(x_pts, y_pts, linestyle='dashed', marker='x', markersize=3)
            plt.errorbar(x_pts, y_pts, e_pts, linestyle='None')
            plt.show()

    def paintGUI(self, window_name='cv2_mouse_paint "enter" to quit', size=256):
        print("\n|" + sys._getframe().f_code.co_name)

        side_arange = np.arange(0, size, dtype=np.uint8)[np.newaxis, :]

        def paint_brush(event, x, y, __flags, __param):  # mouse callback function
            global ix, iy, drawing

            if event == cv2.EVENT_LBUTTONDOWN:
                ix, iy = x, y
                drawing = True
            elif event == cv2.EVENT_MOUSEMOVE and 'drawing' in globals():
                cv2.line(img, (ix, iy), (x, y), 255, size // 64)
                img_show[:, :] = img.copy()
                ix, iy = x, y

                point_sum = np.sum(img_show)

                x_sum = np.sum(img_show, axis=0)
                pX = np.sum(x_sum * side_arange) // point_sum

                y_sum = np.sum(img_show, axis=1)
                pY = np.sum(y_sum * side_arange) // point_sum

                x_active = np.where(x_sum > 0)[0]
                x_half = int((x_active[-1] - x_active[0]) * 0.735)
                y_active = np.where(y_sum > 0)[0]
                y_half = int((y_active[-1] - y_active[0]) * 0.735)

                cv2.rectangle(img_show, (pX - x_half, pY - y_half), (pX + x_half, pY + y_half), 127, 4)

                text = [pX, pY]

                cv2.putText(img_show, str(text), (12, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.5, 255, 1, cv2.LINE_AA)
                # img_show = img_show.copy()
            elif event == cv2.EVENT_LBUTTONUP:
                del drawing
            elif event == cv2.EVENT_RBUTTONDOWN:
                cv2.rectangle(img, (0, 0), (size, size), 0, -1)
                cv2.rectangle(img_show, (0, 0), (size, size), 0, -1)

        img = np.zeros((size, size), np.uint8)
        img_show = img.copy()

        cv2.namedWindow(window_name)
        cv2.setMouseCallback(window_name, paint_brush)

        not_break = True
        while not_break:
            k = cv2.waitKey(1) & 0xFF
            not_break = not bool(k == 133 or k == 27)  # quit(press Esc or Enter)
            cv2.imshow(window_name, img_show)
        cv2.destroyWindow(window_name)


G = GlobalVariable()
T = Tools()
np.random.seed(1943)


def img_regular_resize(img):
    point_sum = np.sum(img)

    side_arange = np.arange(0, img.shape[-2], dtype=np.uint8)

    x_sum = np.sum(img, axis=0)
    pX = np.sum(x_sum * side_arange) / point_sum
    x_active = np.where(x_sum > 0)[0]
    x_half = (x_active[-1] - x_active[0]) * 0.5

    y_sum = np.sum(img, axis=1)
    pY = np.sum(y_sum * side_arange) / point_sum
    y_active = np.where(y_sum > 0)[0]
    y_half = (y_active[-1] - y_active[0]) * 0.5

    # xy_min = (x_half + y_half) // 2
    # if x_half > y_half:
    #     x_half, y_half = x_half, xy_min
    # else:
    #     x_half, y_half = xy_min, y_half

    attention = np.zeros((28, 28), np.uint8)
    attention[int(pX - x_half):int(pX + x_half), int(pY - y_half):int(pY + y_half)] = 255
    img = np.concatenate((img[:, :, np.newaxis], attention[:, :, np.newaxis]), axis=2)
    img = cv2.resize(img, (G.side, G.side))
    return img


def img_resize(img):
    return cv2.resize(img, (G.side, G.side))


def img_mp_pool(images):
    images = (images * 255).astype(np.uint8)

    import multiprocessing as mp
    with mp.Pool(processes=4) as pool:
        res = pool.map(func=img_resize, iterable=images)
        # res = pool.map(func=img_regular_resize, iterable=images)
    # res = [img_regular_resize(img) for img in images]

    res = np.array(res, np.float32) / 255.0
    res = res.reshape((-1, G.side, G.side, 1))
    return res


def load_mnist_data(data_dir='MNIST_data', npz_name='mnist.npz'):
    print("||" + load_mnist_data.__name__)

    npz_path = path.join(data_dir, npz_name)

    if path.exists(npz_path):
        data_para = np.load(npz_path)['arr_0']
    else:
        '''ignore warnings temporary'''
        previous_verbosity = tf.logging.get_verbosity()
        tf.logging.set_verbosity(tf.logging.ERROR)
        from tensorflow.examples.tutorials.mnist import input_data
        data_sets = input_data.read_data_sets(data_dir, one_hot=True)
        tf.logging.set_verbosity(previous_verbosity)

        train_labels = data_sets.train.labels
        train_images = data_sets.train.images

        test_labels = data_sets.test.labels
        test_images = data_sets.test.images

        data_para = (train_images, train_labels, test_images, test_labels)
        data_para = [np.array(ary, dtype=np.float32) for ary in data_para]

        '''images regular'''
        data_para[0] = img_mp_pool(data_para[0].reshape((-1, 28, 28)))
        data_para[2] = img_mp_pool(data_para[2].reshape((-1, 28, 28)))

        np.savez_compressed(path.join(data_dir, npz_name), data_para)

    [T.ary_check(ary) for ary in data_para]
    return data_para


def load_model():
    config = tf.ConfigProto(gpu_options=tf.GPUOptions(per_process_gpu_memory_fraction=0.95))
    config.gpu_options.allow_growth = True
    sess = tf.Session(config=config)

    saver = tf.train.Saver()
    if path.exists(path.join(G.model_dir, 'checkpoint')):
        saver.restore(sess, G.model_path)
        print("| Load:", G.model_path)
    else:
        sess.run(tf.global_variables_initializer())
        print("| Init:", G.model_path)
        os.makedirs(G.model_dir, exist_ok=True)
    return sess, saver


def ckpt2npz():
    sess = tf.Session()[0]

    # for i in tf.trainable_variables():
    for i in tf.global_variables():
        print('\n', i.name)
        npy_name = str(i.name).replace('/', '-').replace(':', '.') + '.npy'
        np.save(npy_name, i.eval(session=sess))
        print(i.eval(session=sess))

    for i in tf.global_variables():
        print('\n', i.name)
        npy_name = str(i.name).replace('/', '-').replace(':', ';') + '.npy'
        sess.run(i.assign(np.load(npy_name)))


def model_init():
    print('||' + model_init.__name__)
    tf.reset_default_graph()

    '''dense net pooling'''
    inp = tf.placeholder(tf.float32, [None, G.side, G.side, 1])
    ans = tf.placeholder(tf.float32, [None, 10])  # 0~9 == 10 classes
    keep = tf.placeholder_with_default(1.0, [])

    ten = tf.layers.conv2d(inp, 4, 2, 1, padding='same')
    ten = tf.nn.leaky_relu(ten)
    ten = tf.contrib.layers.batch_norm(ten)
    ten = tf.concat((inp, ten), axis=3)
    ten = tf.layers.average_pooling2d(ten, 2, 2, padding='valid')
    ten1 = ten

    ten = tf.layers.conv2d(ten1, 8, 2, 1, padding='same')
    ten = tf.nn.leaky_relu(ten)
    ten = tf.contrib.layers.batch_norm(ten)
    ten = tf.concat((ten1, ten), axis=3)
    ten = tf.layers.average_pooling2d(ten, 2, 2, padding='valid')
    ten2 = ten

    ten = tf.layers.conv2d(ten2, 16, 2, 1, padding='same')
    ten = tf.nn.leaky_relu(ten)
    ten = tf.contrib.layers.batch_norm(ten)
    ten = tf.concat((ten2, ten), axis=3)
    ten = tf.layers.average_pooling2d(ten, 2, 2, padding='valid')
    ten3 = ten

    # out = ten3
    ten = tf.layers.conv2d(ten3, 32, 4, 1, padding='valid')
    ten = tf.reshape(ten, (-1, 32))
    ten = tf.layers.dropout(ten, rate=keep)
    out = tf.layers.dense(ten, 10)

    # loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=ans, logits=out))
    loss = tf.losses.log_loss(labels=ans, predictions=tf.nn.softmax(out))
    opt = tf.train.AdamOptimizer(G.learning_rate).minimize(loss)

    return inp, ans, keep, out, loss, opt


def model_train(model_para, data):
    print("||" + model_train.__name__)
    train_images, train_labels, _, _ = data
    inp, ans, keep, out, loss, opt = model_para

    sess, saver = load_model()
    logs = open(G.txt_path, 'a')
    previous_train_epoch = sum(1 for _ in open(G.txt_path)) if path.exists(G.txt_path) else 0
    print('| Train_epoch: %6d+%6d' % (previous_train_epoch, G.train_epoch))
    print('| Batch_epoch: %6dx%6d' % (G.batch_epoch, G.batch_size))

    feed_dict = {}
    sort_key = [i for i in range(G.batch_epoch * G.batch_size)]
    start_time = show_time = save_time = time.time()
    for epoch in range(G.train_epoch):
        batch_losses = []
        np.random.shuffle(sort_key)
        for i in range(G.batch_epoch):
            j = i * G.batch_size
            batch_sort_key = sort_key[j: j + G.batch_size]
            feed_dict[inp] = train_images[batch_sort_key]
            feed_dict[ans] = train_labels[batch_sort_key]
            feed_dict[keep] = np.random.uniform(0.7, 0.9)
            batch_losses.append(sess.run([loss, opt], feed_dict)[0])
            if i % (G.batch_epoch // 8 + 1) == 0:
                print(end='=')
                sys.stdout.flush()

        loss_average = np.average(batch_losses)
        loss_error = float(np.std(batch_losses))
        logs.write('%e %e\n' % (loss_average, loss_error))

        if time.time() - show_time > G.show_gap:
            show_time = time.time()
            remain_epoch = G.train_epoch - epoch
            remain_time = (show_time - start_time) * remain_epoch / (epoch + 1)
            print(end="\n|  %3d s  %3d epoch |Loss: %10.4e" % (remain_time, remain_epoch, loss_average))
        elif time.time() - save_time > G.save_gap:
            save_time = time.time()
            saver.save(sess, G.model_path, write_meta_graph=False)
            logs.close()
            logs = open(G.txt_path, 'a')
            print(end="\n|SAVE")
    saver.save(sess, G.model_path, write_meta_graph=False)
    print("\n| Save:", G.model_path)
    print('| Batch_epoch: %dx%d' % (G.batch_epoch, G.batch_size))
    print('| Train_epoch: %d' % G.train_epoch)
    print('| TimeUsed:    %d' % int(time.time() - start_time))
    logs.close()
    sess.close()


def model_eval(model_para, data):
    print('||' + model_eval.__name__)
    train_images, train_labels, test_images, test_labels = data
    inp, ans, keep, out, loss, opt = model_para

    sess, _ = load_model()

    for eval_type, eval_inp, eval_ans in (
            ('Train_set', train_images[:G.test_size], train_labels[:G.test_size]),
            ('Test_set ', test_images[:G.test_size], test_labels[:G.test_size])
    ):
        sess_out = out.eval(feed_dict={inp: eval_inp}, session=sess)
        accuracy = np.average(np.equal(np.argmax(sess_out, 1), np.argmax(eval_ans, 1)))
        inaccuracy = 1.0 - accuracy
        print('| %s |Accuracy: %2.4f%% |Error: %.2e' % (eval_type, accuracy * 100, inaccuracy))
    sess.close()
    tf.reset_default_graph()  # release the Video Memory


def run():
    model_data = load_mnist_data()
    model_para = model_init()

    shutil.rmtree(G.model_dir, ignore_errors=True), print("| remove model_dir")

    model_train(model_para, model_data)
    model_eval(model_para, model_data)

    T.draw_plot(G.txt_path)


if __name__ == '__main__':
    run()
