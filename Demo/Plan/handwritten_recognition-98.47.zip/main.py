import os


class GlobalVariable(object):
    train_epoch = 2 ** 6  # accuracy in test_set 99.05%
    train_size = 55000  # MNIST_train_size
    batch_size = min(5500, train_size)  # 2**13
    batch_epoch = train_size // batch_size

    test_size = 11000
    side = 32  # 2 ** 6
    show_gap = 2 ** 2  # time
    save_gap = 2 ** 7  # time
    learning_rate = 2 ** -10

    model_dir = 'handwritten_recognition'
    model_name = 'neural_networks'
    model_path = os.path.join(model_dir, model_name)
    txt_path = os.path.join(model_dir, 'training_npy.txt')


if __name__ == '__main__':
    from handwritten_recognition import run

    run()
